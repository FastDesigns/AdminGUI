import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class SelectClassScreen extends JPanel {
	private JButton logoutBtn;
	private JButton enterBtn;
	private JButton importBtn;
	private JButton exportBtn;
	
	private JLabel selectLabel;
	
	private JScrollPane classPane;
	private JComboBox classCombo;
	private JList classList;
	private JList students;
	private String[] classes;
	
	
	private JFrame mainFrame;
	
	private JPanel topPanel;
	private JPanel middlePanel;
	private JPanel bottomPanel;
	
	private String user;
	private JFileChooser fc;
	
	public SelectClassScreen(JFrame main, String teacher)
	{
		this.mainFrame = main;
		this.user = teacher;
		makeButtons();
		makeLabel();
		makeClasses();
		makePanels();
		addButtons();
	
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		fc = new JFileChooser();
		fc.setCurrentDirectory(new File(System.getProperty("user.home")));
	}
	public void makeButtons()
	{
		logoutBtn = new JButton("Logout");
		importBtn = new JButton("Import");
		enterBtn = new JButton("Take Attendance");
		exportBtn = new JButton("Export");
		
		logoutBtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				logoutAction(); // helper function for loginBtn
				}});
		enterBtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				enterAction(); // helper function for enterBtn
				}});
		
		importBtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				importAction(); // helper function for exportBtn
//				System.out.println("You pressed export");
				}});
		exportBtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				exportAction(); // helper function for exportBtn
				//System.out.println("You pressed export");
				}});
	}
	
	public void makeLabel()
	{
		selectLabel = new JLabel("Select Class");
		selectLabel.setForeground(Color.black);
	}
	
	public void makeClasses()
	{
//		int numClasses = 3; // get this number from database
//		classes = new String[numClasses];
		classPane = new JScrollPane();
		String[] classes = GetClassListForTeacher.getClassList(new String[] {user});
		classCombo = new JComboBox(classes);
//		classList = new JList(classes);
//		classList.setSize(300, 600);
//		classPane.add(classList);
//		code to generate classes
//		String[] fake = {"one", "two", "three", "","","","",""};
		students = new JList();
//		classPane.add(students);
//		students.setSize(1280,720);
		
//		students.setSize(600,600);
		
	}
	
	public void makePanels()
	{
		topPanel = new JPanel();
		middlePanel = new JPanel(new GridLayout(1,1));
		bottomPanel = new JPanel();
		
		topPanel.setOpaque(false);
		middlePanel.setOpaque(false);
		bottomPanel.setOpaque(false);
	}
	public void addButtons()
	{
//		this.setLayout(new FlowLayout());
		this.setLayout(new GridLayout(3,1));
//		this.setBounds(15, 15, 600, 600);
		this.setBounds(0,0,1280,720);
		this.setOpaque(false);
		topPanel.add(selectLabel);
		topPanel.add(classCombo);
//		middlePanel.add(classCombo);
//		middlePanel.add(classPane);// dont even know what this is doing but it is most likely wrong
		middlePanel.add(students);
		bottomPanel.add(logoutBtn);
		bottomPanel.add(enterBtn);
		bottomPanel.add(importBtn);
		bottomPanel.add(exportBtn);
		this.add(topPanel);
		this.add(middlePanel);
		this.add(bottomPanel);
		mainFrame.add(this);
	}
	
	
	
	public void logoutAction()
	{
		this.removeAll();
//		this.paintImmediately(0,0,1280,720); //https://community.oracle.com/thread/1350756?start=0&tstart=0
		StartScreen start = new StartScreen(mainFrame);
	}
	
	public void enterAction()
	{
//		need some code to grab selection 
//		create new class screen. pass mainFrame and string with classname
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		TakeAttendance.recordAttendance(classCombo.getSelectedItem().toString(),dateFormat.format(date));
		String[] Students = GetAttendance.getAttendance(new String[] {classCombo.getSelectedItem().toString(), dateFormat.format(date)}); 
//		students = new JList(Students);
		students.setListData(Students);
		students.repaint();
		middlePanel.repaint();
//		this.paintImmediately(0, 0, 1280, 720);
		
	}
	
	public void importAction(){
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		String classname = (String) classCombo.getSelectedItem();
		JFrame pop = new JFrame();
		int result = fc.showOpenDialog(pop);
		
		if ( result == JFileChooser.APPROVE_OPTION) {
			File file = fc.getSelectedFile();
			String filename = file.getName();
			ReadFile read = new ReadFile(file, filename, classname);
			read.setInputFile(filename);
			try {
				read.read();}
			catch (IOException e) {
				System.out.println("Learn 2 read good");
				e.printStackTrace();
			}
		}
	}
	
	public void exportAction()
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		// http://www.codejava.net/java-se/swing/show-save-file-dialog-using-jfilechooser
		fc.setDialogTitle("Specify a file to save"); 
		int userSelection = fc.showSaveDialog(mainFrame);
		 
		if (userSelection == fc.APPROVE_OPTION) {
		    File fileToSave = fc.getSelectedFile();
		    System.out.println("Save as file: " + fileToSave.getAbsolutePath());
		}
		WriteFile write = new WriteFile(classCombo.getSelectedItem().toString(), dateFormat.format(date));
		write.print();
	}
}
