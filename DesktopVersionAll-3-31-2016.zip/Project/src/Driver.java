import javax.swing.JFrame;

public class Driver
{
	public static void main(String[] args)
	{
		//desktopGUI window = new desktopGUI();
		//window.setVisible(true);
		JFrame main = new JFrame();
		StartScreen start = new StartScreen(main);
		
	}
}