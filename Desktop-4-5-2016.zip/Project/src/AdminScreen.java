import javax.swing.*;

public class AdminScreen extends JPanel
{

	private JFrame mainFrame;
	
	private JPanel currentWindow, previousWindow;
	
	public AdminScreen(JFrame main)
	{
		this.mainFrame = main;
	}
}
